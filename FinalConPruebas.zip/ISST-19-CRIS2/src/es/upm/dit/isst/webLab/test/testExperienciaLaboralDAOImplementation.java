package es.upm.dit.isst.webLab.test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.fail;
import static org.junit.jupiter.api.Assertions.*;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import es.upm.dit.isst.webLab.dao.ExperienciaLaboralDAO;
import es.upm.dit.isst.webLab.dao.ExperienciaLaboralDAOImplementation;
import es.upm.dit.isst.webLab.model.ExperienciaLaboral;
import es.upm.dit.isst.webLab.model.Idiomas;


class testExperienciaLaboralDAOImplementation {

	
	private Date fecha;
	private ExperienciaLaboralDAO form;
	private String email = "guillermo@gmail.com";
	private ExperienciaLaboral experiencia1;
	private ExperienciaLaboral experiencia2;

	
	@BeforeEach
	void setUp() throws Exception {		
		form  = ExperienciaLaboralDAOImplementation.getInstance();
		
		//Fechas
		SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-yyyy");
		fecha = null;
		try {
			fecha = sdf.parse("10-10-2010");
		} catch (ParseException e) {
			e.printStackTrace();
		}
		experiencia1 = new ExperienciaLaboral("rrhh manager","deloitte", fecha, fecha, true, "en rrhh");
		experiencia2 = new ExperienciaLaboral("recepcionista", "residencia", fecha, fecha, false, "encargado de rececpi� a media jornada");
		experiencia2.setEmail(email);
		experiencia1.setEmail(email);
		
	}

	@AfterEach
	void tearDown() throws Exception {
		try {
			form.delete(experiencia1);
			form.delete(experiencia2);
		} catch(Exception e) {}
	}

	
	@Test
	void testCreate() {
	
		form.create(experiencia1);
		form.create(experiencia2);
		
		List<ExperienciaLaboral> form1Test = (List) form.read(email);
		
		
		assertEquals("Se guardaron los dos objetos??", 2, form1Test.size());
		assertEquals("La experiencia 1 se guard� bien?", experiencia1.getPuesto(), form1Test.get(0).getPuesto());
		assertEquals("El experiencia 2 se guard� bien?", experiencia2.getPuesto(), form1Test.get(1).getPuesto());
	}
	
	@Test
	void testRead() {

		assertEquals("Carga una lista vac�a si no hay objetos??", 0, form.read(email).size());
		
		form.create(experiencia1);
		form.create(experiencia2);
		
		List<ExperienciaLaboral> form1Test = (List) form.read(email);
		
		assertNotNull("Funciona la funci�n cargar?",form1Test);
		assertEquals("Se guardaron los dos objetos??", 2, form1Test.size());
		assertEquals("La experiencia 1 se carga bien?", experiencia1.getPuesto(), form1Test.get(0).getPuesto());
		assertEquals("El experiencia 2 se carga bien?", experiencia2.getPuesto(), form1Test.get(1).getPuesto());
	}
	
	@Test
	void testDelete() {
		
		form.create(experiencia1);
		form.create(experiencia2);
		

		
		List<ExperienciaLaboral> form1Test = (List) form.read(email);
		
		assertEquals("Se guardaron los dos objetos??", 2, form1Test.size());
		
		form.delete(experiencia2);
		form.delete(new ExperienciaLaboral());
		form1Test = (List) form.read(email);
		
		assertEquals("Se borr� el objeto bien?? Y no ocurri� nada al borrar un objeto que no est�?", 1, form1Test.size());
		assertNotEquals("Y el que queda no es el que borr�?", experiencia2.getPuesto(),form1Test.get(0).getPuesto());
		
		
	}
	

	@Test
	void testUpdate() {
		
		form.create(experiencia1);
		form.create(experiencia2);
		
		List<ExperienciaLaboral> form1Test = (List) form.read(email);
		
		assertEquals("Se guardaron los dos objetos??", 2, form1Test.size());
		
		experiencia2.setPuesto("Cuidador de ni�os");
		form.update(experiencia2);	
		
		form1Test = (List) form.read(email);
		String titulacionTest = form1Test.get(1).getPuesto();
		
		assertEquals("Se actualiz� el objeto??", "Cuidador de ni�os", titulacionTest);
	
	}

}
