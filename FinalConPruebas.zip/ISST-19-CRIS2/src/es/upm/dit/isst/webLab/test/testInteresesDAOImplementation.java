package es.upm.dit.isst.webLab.test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.jupiter.api.Assertions.*;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import es.upm.dit.isst.webLab.dao.FormacionAcademicaDAO;
import es.upm.dit.isst.webLab.dao.FormacionAcademicaDAOImplementation;
import es.upm.dit.isst.webLab.dao.InteresesDAO;
import es.upm.dit.isst.webLab.dao.InteresesDAOImplementation;
import es.upm.dit.isst.webLab.model.ExperienciaLaboral;
import es.upm.dit.isst.webLab.model.Formaci�nAcad�mica;
import es.upm.dit.isst.webLab.model.Intereses;

class testInteresesDAOImplementation {

	private Date fecha;
	private InteresesDAO idao;
	private String email = "guillermo@gmail.com";
	private Intereses intereses1;
	private Intereses intereses2;

	
	@BeforeEach
	void setUp() throws Exception {		
		idao  = InteresesDAOImplementation.getInstance();
		
		//Fechas
		SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-yyyy");
		fecha = null;
		try {
			fecha = sdf.parse("10-10-2010");
		} catch (ParseException e) {
			e.printStackTrace();
		}
		intereses1 = new Intereses(email, "Deporte", "futbol");
		intereses2 = new Intereses(email, "Deporte", "baloncesto");
		
	}

	@AfterEach
	void tearDown() throws Exception {
		try {
			idao.delete(intereses1);
			idao.delete(intereses2);
		} catch(Exception e) {}
	}

	
	@Test
	void testCreate() {
	
		idao.create(intereses1);
		idao.create(intereses2);
				
		List<Intereses> form1Test = (List) idao.read(email);
		
		assertEquals("Se guardaron los dos objetos??", 2, form1Test.size());
		assertEquals("El form 1 se guard� bien?", intereses1.getDescripci�n(), form1Test.get(0).getDescripci�n());
		assertEquals("El form 2 se guard� bien?", intereses2.getDescripci�n(), form1Test.get(1).getDescripci�n());

	}
	
	@Test
	void testRead() {
		
		assertEquals("Carga una lista vac�a si no hay objetos??", 0, idao.read(email).size());

		idao.create(intereses1);
		idao.create(intereses2);
		
		List<Intereses> form1Test = (List) idao.read(email);
		assertNotNull("Funciona la funci�n cargar?",form1Test);
		assertEquals("Se guardaron los dos objetos??", 2, form1Test.size());
		assertEquals("El form 1 se carga bien?", intereses1.getDescripci�n(), form1Test.get(0).getDescripci�n());
		assertEquals("El form 2 se carga bien?", intereses2.getDescripci�n(), form1Test.get(1).getDescripci�n());

	}
	
	@Test
	void testDelete() {
		
		idao.create(intereses1);
		idao.create(intereses2);
		
		List<Intereses> form1Test = (List) idao.read(email);
		
		assertEquals("Se guardaron los dos objetos??", 2, form1Test.size());
		
		idao.delete(intereses2);
		idao.delete(new Intereses());

		form1Test = (List) idao.read(email);
		

		assertEquals("Se borr� el objeto bien?? Y no ocurri� nada al borrar un objeto que no est�?", 1, form1Test.size());
		assertNotEquals("Y el que queda no es el que borr�?", intereses2.getDescripci�n(),form1Test.get(0).getDescripci�n());
		
		
	}
	
	@Test
	void testReadAll() {
	//No lo usamos
	}
	
	@Test
	void testUpdate() {
		
		idao.create(intereses1);
		idao.create(intereses2);
		
		List<Intereses> form1Test = (List) idao.read(email);
		
		assertEquals("Se guardaron los dos objetos??", 2, form1Test.size());
		
		intereses2.setDescripci�n("Volleyball");
		idao.update(intereses2);	
		
		form1Test = (List) idao.read(email);
		String descripcionTest = form1Test.get(1).getDescripci�n();
		
		assertEquals("Se actualiz� el objeto??", "Volleyball", descripcionTest);
	
	}

}
