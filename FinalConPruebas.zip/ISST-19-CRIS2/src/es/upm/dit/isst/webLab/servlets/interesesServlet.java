package es.upm.dit.isst.webLab.servlets;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import es.upm.dit.isst.webLab.dao.InteresesDAO;
import es.upm.dit.isst.webLab.dao.InteresesDAOImplementation;
import es.upm.dit.isst.webLab.dao.UserDAO;
import es.upm.dit.isst.webLab.dao.UserDAOImplementation;
import es.upm.dit.isst.webLab.model.Intereses;

@WebServlet({ "/intereses" })
public class interesesServlet extends HttpServlet {


	private static final long serialVersionUID = 1L;


	@Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {
    		
    
    		getServletContext().getRequestDispatcher( "/cvInfoView.jsp" ).forward( req, resp );
    	
    }
	
	
	  @Override
	    protected void doPost(HttpServletRequest req, HttpServletResponse resp)
	            throws ServletException, IOException {
		   
		  
		  	String email = req.getParameter("email");
		  	String habilidad = req.getParameter("habilidad");
		  	String descripcion = req.getParameter("descripcion");
		  	System.out.println("la habilidad es :" + habilidad);
		  	System.out.println("la descripcion es :" + descripcion);
		  	System.out.println("la email es :" + email);
			Intereses interes = new Intereses();
			
			UserDAO userdao = UserDAOImplementation.getInstance();
			InteresesDAO interesesdao = InteresesDAOImplementation.getInstance();	
			interes.setDescripci�n(descripcion);
			interes.setTipoSecci�n(habilidad);
			interes.setEmail(email);
			interes.setUserForm(userdao.read(email));
			
			interesesdao.create(interes);
			interesesdao.read(email).forEach(Intereses -> System.out.println(Intereses.getTipoSecci�n()));
			req.getSession().setAttribute("intereses", interesesdao.read(email));

			getServletContext().getRequestDispatcher( "/cvInfoView.jsp" ).forward( req, resp );

	    }
	
}
