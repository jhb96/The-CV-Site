package es.upm.dit.isst.webLab.dao;

import java.util.Collection;

import es.upm.dit.isst.webLab.model.Idiomas;
import es.upm.dit.isst.webLab.model.Intereses;

public interface InteresesDAO {

	public void create(Intereses interes); 
	
	public Collection<Intereses> read(String email);
	
	public void update(Intereses interes); 
	
	public void delete(Intereses interes); 
	
	public void delete(Integer id); 
	
	public Collection<Intereses> readAll();
}
