package es.upm.dit.isst.webLab.test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.jupiter.api.Assertions.*;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import es.upm.dit.isst.webLab.dao.IdiomasDAO;
import es.upm.dit.isst.webLab.dao.IdiomasDAOImplementation;
import es.upm.dit.isst.webLab.dao.InteresesDAO;
import es.upm.dit.isst.webLab.dao.InteresesDAOImplementation;
import es.upm.dit.isst.webLab.model.ExperienciaLaboral;
import es.upm.dit.isst.webLab.model.Idiomas;
import es.upm.dit.isst.webLab.model.Idiomas;

class testIdiomasDAOImplementation {

	private IdiomasDAO idao;
	private String email = "guillermo@gmail.com";
	private Idiomas idioma1;
	private Idiomas idioma2;

	
	@BeforeEach
	void setUp() throws Exception {		
		idao  = IdiomasDAOImplementation.getInstance();
	
		idioma1 = new Idiomas("ingl�s", "alto", null, null);				
		idioma2 = new Idiomas("franc�s", "bajo", null, null);
		idioma1.setEmail(email);
		idioma2.setEmail(email);
		
	}

	@AfterEach
	void tearDown() throws Exception {
		try {
			idao.delete(idioma1);
			idao.delete(idioma2);
		} catch(Exception e) {}
	}

	
	@Test
	void testCreate() {
	
		idao.create(idioma1);
		idao.create(idioma2);
				
		List<Idiomas> form1Test = (List) idao.read(email);
		
		assertEquals("Se guardaron los dos objetos??", 2, form1Test.size());
		assertEquals("El idioma 1 se guard� bien?", idioma1.getIdioma(), form1Test.get(0).getIdioma());
		assertEquals("El idioma2 2 se guard� bien?", idioma2.getIdioma(), form1Test.get(1).getIdioma());

	}
	
	@Test
	void testRead() {
		
		assertEquals("Carga una lista vac�a si no hay objetos??", 0, idao.read(email).size());

		idao.create(idioma1);
		idao.create(idioma2);
		
		List<Idiomas> form1Test = (List) idao.read(email);
		
		assertNotNull("Funciona la funci�n cargar?",form1Test);
		assertEquals("Se guardaron los dos objetos??", 2, form1Test.size());
		assertEquals("El form 1 se carga bien?", idioma1.getIdioma(), form1Test.get(0).getIdioma());
		assertEquals("El form 2 se carga bien?", idioma2.getIdioma(), form1Test.get(1).getIdioma());

	}
	
	@Test
	void testDelete() {
		
		idao.create(idioma1);
		idao.create(idioma2);
		
		List<Idiomas> form1Test = (List) idao.read(email);
		
		assertEquals("Se guardaron los dos objetos??", 2, form1Test.size());
		
		idao.delete(idioma2);	
		idao.delete(new Idiomas());

		form1Test = (List) idao.read(email);


		assertEquals("Se borr� el objeto bien?? Y no ocurri� nada al borrar un objeto que no est�?", 1, form1Test.size());
		assertNotEquals("Y el que queda no es el que borr�?", idioma2.getIdioma(),form1Test.get(0).getIdioma());
		
		
	}
	
	@Test
	void testReadAll() {
	//No lo usamos
	}
	
	@Test
	void testUpdate() {
		
		idao.create(idioma1);
		idao.create(idioma2);
		
		List<Idiomas> form1Test = (List) idao.read(email);
		
		assertEquals("Se guardaron los dos objetos??", 2, form1Test.size());
		
		idioma2.setIdioma("Italiano");
		idao.update(idioma2);	
		
		form1Test = (List) idao.read(email);
		String idiomaTest = form1Test.get(1).getIdioma();
		
		assertEquals("Se actualiz� el objeto??", "Italiano", idiomaTest);
	
	}
}