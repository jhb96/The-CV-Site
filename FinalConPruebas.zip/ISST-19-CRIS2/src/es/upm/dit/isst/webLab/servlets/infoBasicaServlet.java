package es.upm.dit.isst.webLab.servlets;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import es.upm.dit.isst.webLab.dao.UserDAO;
import es.upm.dit.isst.webLab.dao.UserDAOImplementation;
import es.upm.dit.isst.webLab.model.Informaci�nB�sica;
import es.upm.dit.isst.webLab.model.User;

@WebServlet({ "/infoBasica" })
public class infoBasicaServlet extends HttpServlet {

	private static final long serialVersionUID = 1L;

	@Override
	    protected void doPost(HttpServletRequest req, HttpServletResponse resp)
	            throws ServletException, IOException {
		  	  
			String nombre = req.getParameter( "Nombre" );
			String apellidos = req.getParameter( "Apellidos" );
			String email = (String) req.getSession().getAttribute("email");
			String direccion = req.getParameter( "Direccion" );
			String ciudad = req.getParameter("Ciudad");
			String telefono = req.getParameter("Telefono");
			String perfil = req.getParameter("Perfil");

			UserDAO udao = UserDAOImplementation.getInstance();
			
			User userActivo = udao.read(email);		
			System.out.println("�Se ha cargado bien el user?");

			Informaci�nB�sica infoBasicaActual = new Informaci�nB�sica(nombre, apellidos, email, direccion, ciudad, telefono, perfil);
		
			
			userActivo.setInformaci�nB�sica(infoBasicaActual);
			userActivo.setEmail(email);
			
			udao.update(userActivo);
			
			req.getSession().setAttribute("informacionbasica", userActivo.getInformaci�nB�sica());
			
			getServletContext().getRequestDispatcher( "/cvInfoView.jsp" ).forward( req, resp );

	    }
	
	
	
	
}
