package es.upm.dit.isst.webLab.servlets;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;

import es.upm.dit.isst.webLab.dao.IdiomasDAO;
import es.upm.dit.isst.webLab.dao.IdiomasDAOImplementation;
import es.upm.dit.isst.webLab.dao.UserDAO;
import es.upm.dit.isst.webLab.dao.UserDAOImplementation;
import es.upm.dit.isst.webLab.model.Idiomas;


@MultipartConfig
@WebServlet({ "/idiomas" })
public class idiomasServlet extends HttpServlet{


	private static final long serialVersionUID = 1L;


	@Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {
    	
    
    		getServletContext().getRequestDispatcher( "/cvInfoView.jsp" ).forward( req, resp );
    }
	
	
	  @Override
	    protected void doPost(HttpServletRequest req, HttpServletResponse resp)
	            throws ServletException, IOException {
		  
		 
		  	String email = req.getParameter("email");
		  	String idiomaName = req.getParameter("idiomas");
		  	String nivel = req.getParameter("nivel");
		  	String capacidad = req.getParameter("capacidad");
		  	
			
		  	
		  	//CERTIFICADO
			Part filePart = req.getPart("Certificado");
			InputStream fileContent = filePart.getInputStream();
			ByteArrayOutputStream output = new ByteArrayOutputStream();
			byte[] buffer = new byte[10240];
			for (int length = 0; (length = fileContent.read(buffer)) > 0;) output.write(buffer, 0, length);
			
			
			UserDAO udao = UserDAOImplementation.getInstance();		
			
			IdiomasDAO idiomasdao = IdiomasDAOImplementation.getInstance();
			
			
			Idiomas idioma = new Idiomas();
			
			idioma.setIdioma(idiomaName);
			idioma.setNivel(nivel);
			idioma.setEmail(email);
			idioma.setUserForm(udao.read(email));
			idioma.setCapacidad(capacidad);
			idioma.setCertificado(output.toByteArray());
			output.toByteArray();
			
			idiomasdao.create(idioma);
			
			idiomasdao.read(email).forEach(Idiomas -> System.out.println(Idiomas.getIdioma()));
			req.getSession().setAttribute("idiomas", idiomasdao.read(email));
			getServletContext().getRequestDispatcher( "/cvInfoView.jsp" ).forward( req, resp );

	    }
	
	
}
