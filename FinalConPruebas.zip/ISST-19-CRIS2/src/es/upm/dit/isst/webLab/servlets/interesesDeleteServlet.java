package es.upm.dit.isst.webLab.servlets;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import es.upm.dit.isst.webLab.dao.ExperienciaLaboralDAO;
import es.upm.dit.isst.webLab.dao.ExperienciaLaboralDAOImplementation;
import es.upm.dit.isst.webLab.dao.FormacionAcademicaDAO;
import es.upm.dit.isst.webLab.dao.FormacionAcademicaDAOImplementation;
import es.upm.dit.isst.webLab.dao.IdiomasDAO;
import es.upm.dit.isst.webLab.dao.IdiomasDAOImplementation;
import es.upm.dit.isst.webLab.dao.InteresesDAO;
import es.upm.dit.isst.webLab.dao.InteresesDAOImplementation;
import es.upm.dit.isst.webLab.dao.UserDAO;
import es.upm.dit.isst.webLab.dao.UserDAOImplementation;
import es.upm.dit.isst.webLab.model.Informaci�nB�sica;
import es.upm.dit.isst.webLab.model.User;


@WebServlet("/interesesDelete")
public class interesesDeleteServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    public interesesDeleteServlet() {
        super();
    
    }

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		InteresesDAO intdao = InteresesDAOImplementation.getInstance();
		String email = (String) request.getSession().getAttribute("email");
		Integer id =  (int) Long.parseLong(request.getParameter("idintid"));
		System.out.println("La id es:" +id);
		System.out.println("La email es:" +email);
		intdao.delete(id);
	
		
		
		intdao.read(email).forEach(Intereses -> System.out.println(Intereses.getTipoSecci�n()));
		request.getSession().setAttribute("intereses", intdao.read(email));
		
		
		getServletContext().getRequestDispatcher("/userInfoView.jsp").forward(request, response);
		
	}

}
