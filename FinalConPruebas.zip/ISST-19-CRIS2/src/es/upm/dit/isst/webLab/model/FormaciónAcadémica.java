package es.upm.dit.isst.webLab.model;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;

@Entity
@Table(name = "FORMACIONACADEMICA", uniqueConstraints = {
		@UniqueConstraint(columnNames = "idForm")})
public class Formaci�nAcad�mica implements Serializable{
	
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "idForm", unique = true, nullable = false)
	private Integer idForm;
	
	@ManyToOne
	private User userForm; //Identifica el usuario al que pertenece la formacion

	private String titulaci�n;
	
	private String centro;
	
	@Lob
	byte[] certificado;
	//private File certificado;
	
	
	private Date fechaComienzo;
	
	
	private Date fechaFin;
	
	
	private Boolean actualmente;

	
	private String email; //Identifica el usuario por el email
	
	public Formaci�nAcad�mica() {
		
	}
	
	public Formaci�nAcad�mica(String titulaci�n, String centro, 
			byte[] certificado, Date fechaComienzo, Date fechaFin, Boolean actualmente) {
		
			this.titulaci�n = titulaci�n;
			this.centro = centro;
			this.certificado = certificado;
			this.fechaComienzo = fechaComienzo;
			this.fechaFin = fechaFin;
			this.actualmente = actualmente;
	}	
	
	
	public String getEmail() {
		return email;
	}
	
	public void setEmail(String email) {
		 this.email = email;
	}
	
	public String getTitulaci�n() {
		return titulaci�n;
	}
	
	public void setTitulaci�n(String titulaci�n) {
		 this.titulaci�n = titulaci�n;
	}
	
	
	public String getCentro() {
		return centro;
	}
	
	public void setCentro(String centro) {
		 this.centro = centro;
	}
	
	
	public byte[] getCertificado() {
		return certificado;
	}
	
	public void setCertificado(byte[] certificado) {
		 this.certificado = certificado;
	}
	
	
	public Date getFechaComienzo() {
		return fechaComienzo;
	}
	
	public void setFechaComienzo(Date fechaComienzo) {
		 this.fechaComienzo = fechaComienzo;
	}
	
	
	public Date getFechaFin() {
		return fechaFin;
	}
	
	public void setFechaFin(Date fechaFin) {
		 this.fechaFin = fechaFin;
	}
	
	
	public Boolean getActualmente() {
		return actualmente;
	}
	
	public void setActualmente(Boolean actualmente) {
		 this.actualmente = actualmente;
	}

	public User getUserForm() {
		return userForm;
	}

	public void setUserForm(User userForm) {
		this.userForm = userForm;
	}
	
	public Integer getidForm() {
		return idForm;
	}
}
