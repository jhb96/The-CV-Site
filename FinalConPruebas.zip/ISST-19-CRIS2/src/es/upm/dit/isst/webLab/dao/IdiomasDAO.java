package es.upm.dit.isst.webLab.dao;

import java.util.Collection;

import es.upm.dit.isst.webLab.model.Idiomas;
public interface IdiomasDAO {

		public void create(Idiomas idio); 
		
		public Collection<Idiomas> read(String email);
		
		public void update(Idiomas idio); 
		
		public void delete(Idiomas idio); 
		
		public void delete(Integer id); 
		
		public Collection<Idiomas> readAll();
	}

