package es.upm.dit.isst.webLab.dao;

import java.util.ArrayList;
import java.util.Collection;

import javax.persistence.Query;

import es.upm.dit.isst.webLab.model.Idiomas;
import es.upm.dit.isst.webLab.model.Intereses;

import org.hibernate.Session;


public class IdiomasDAOImplementation implements IdiomasDAO {
	

	private static IdiomasDAOImplementation instancia = null;

	private IdiomasDAOImplementation() {
	}

	public static IdiomasDAOImplementation getInstance() {
		if (null == instancia)
			instancia = new IdiomasDAOImplementation();
		return instancia;
	}

	@Override
	public void create(Idiomas idioma) {
		Session session = SessionFactoryService.get().openSession();
		try {
			session.beginTransaction();
			session.save(idioma);
			session.getTransaction().commit();
		} catch (Exception e) {

		} finally {
			session.close();
		}	
	}

	@Override
	public Collection<Idiomas> read(String email) {
		Session session = SessionFactoryService.get().openSession();
		Collection<Idiomas> idio = new ArrayList<Idiomas>();
		try {
			session.beginTransaction();
			String query = "from Idiomas WHERE EMAIL = '" + email + "'";
			idio = session.createQuery(query).list();
			session.getTransaction().commit();
		} catch (Exception e) {

		} finally {
			session.close();
		}		
		return idio;
	}

	@Override
	public void update(Idiomas idio) {
		Session session = SessionFactoryService.get().openSession();
		try {
			session.beginTransaction();
			session.saveOrUpdate(idio);
			session.getTransaction().commit();
		} catch (Exception e) {

		} finally {
			session.close();
		}
	}

	@Override
	public void delete(Idiomas idio) {
		Session session = SessionFactoryService.get().openSession();
		try {
			session.beginTransaction();
			session.delete(idio);
			session.getTransaction().commit();
		} catch (Exception e) {

		} finally {
			session.close();
		}
	}

	@Override
	@SuppressWarnings({ "unchecked", "finally" })
	public Collection<Idiomas> readAll() {
		Session session = SessionFactoryService.get().openSession();
		Collection<Idiomas> idiomas = null;
		try {
			session.beginTransaction();
			idiomas = session.createQuery("from Idiomas").list();
			System.out.println(idiomas);
			session.getTransaction().commit();
		} catch (Exception e) {

		} finally {
			session.close();
			return idiomas;
		}
	}

	@Override
	public void delete(Integer id) {
		Session session = SessionFactoryService.get().openSession();
		try {
			session.beginTransaction();
			String query = "delete Idiomas WHERE idiomid = '" + id+"'";
			Query q = session.createQuery(query);
			q.executeUpdate();
			session.getTransaction().commit();
		} catch (Exception e) {

		} finally {
			session.close();
		}		
		return ;
	}
	
}
