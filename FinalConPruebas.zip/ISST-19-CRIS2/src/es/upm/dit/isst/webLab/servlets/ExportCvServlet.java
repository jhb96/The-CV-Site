package es.upm.dit.isst.webLab.servlets;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import es.upm.dit.isst.webLab.dao.UserDAO;
import es.upm.dit.isst.webLab.dao.UserDAOImplementation;
import es.upm.dit.isst.webLab.model.Informaci�nB�sica;
import es.upm.dit.isst.webLab.model.User;

import javax.servlet.RequestDispatcher;

 
@WebServlet({ "/exportCv" })
public class ExportCvServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;
 
    public ExportCvServlet() {
        super();
    }
 
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
    	
    	String email = (String)request.getSession().getAttribute("email");
    
    	
    	UserDAO udao = UserDAOImplementation.getInstance();
		User userActivo = udao.read(email);		
		System.out.println(email);
		Informaci�nB�sica infobasica = new Informaci�nB�sica();
    	infobasica = userActivo.getInformaci�nB�sica();
    	request.getSession().setAttribute("informacionbasica",infobasica);
    	
    	
        RequestDispatcher dispatcher 
                = this.getServletContext().getRequestDispatcher("/exportCvView.jsp");
 
        dispatcher.forward(request, response);
    }
 
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
 
        doGet(request, response);
    }
 
}
