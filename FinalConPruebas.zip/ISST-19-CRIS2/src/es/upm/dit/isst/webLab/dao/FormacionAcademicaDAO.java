package es.upm.dit.isst.webLab.dao;

import java.util.Collection;

import es.upm.dit.isst.webLab.model.Formaci�nAcad�mica;;

public interface FormacionAcademicaDAO {
	
	public void create(Formaci�nAcad�mica form); 
	
	public Collection<Formaci�nAcad�mica> read(String email);
	
	public void update(Formaci�nAcad�mica form); 
	
	public void delete(Formaci�nAcad�mica form);
	
	public void delete(Integer idForm);
	
	public 	Collection<Formaci�nAcad�mica> readAll();
	
}
