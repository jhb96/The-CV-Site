package es.upm.dit.isst.webLab.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;

@Entity
@Table(name = "IDIOMAS", uniqueConstraints = {
		@UniqueConstraint(columnNames = "idiomid")})
public class Idiomas implements Serializable {

	private static final long serialVersionUID = 1L;


	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "idiomid", unique = true, nullable = true)
	private Integer idiomid;
	
	
	@ManyToOne
	private User userForm; //Identifica el usuario al que pertenece la formacion
	
	private String email; //Identifica el usuario por el email

	
	private String idioma;
	private String nivel;
	private String capacidad;
	@Lob
	private byte[] certificado;
	
	
	public Idiomas() {}
	
	public Idiomas(String idioma, String nivel, String capacidad, byte[] certificado) {
		this.idioma = idioma;
		this.nivel = nivel;
		this.capacidad = capacidad;
		this.certificado = certificado;
	}

	
	public String getIdioma() {
		return idioma;
	}
	
	public void setIdioma(String idiomaName) {
		this.idioma =  idiomaName;
	}
	
	public void setNivel(String nivel) {
		 this.nivel = nivel;
	}
	public String getNivel() {
		return nivel;
	}
	
	
	
	public byte[] getCertificado() {
		return certificado;
	}
	
	public void setCertificado(byte[] certificado) {
		 this.certificado = certificado;
	}
	
	public User getUserForm() {
		return userForm;
	}

	public void setUserForm(User userForm) {
		this.userForm = userForm;
	}
	
	public String getEmail() {
		return email;
	}
	
	public void setEmail(String email) {
		 this.email = email;
	}

	public void setCapacidad(String capacidad) {
		this.capacidad = capacidad;	
	}
	
	public String getCapacidad() {
		return capacidad;	
	}
	public int getidiomid() {
		return idiomid;
	}
	
}