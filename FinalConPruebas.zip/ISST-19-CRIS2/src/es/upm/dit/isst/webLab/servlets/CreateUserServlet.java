package es.upm.dit.isst.webLab.servlets;
import org.apache.shiro.crypto.hash.Sha256Hash;
import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import es.upm.dit.isst.webLab.dao.UserDAO;
import es.upm.dit.isst.webLab.dao.UserDAOImplementation;
import es.upm.dit.isst.webLab.model.User;

@WebServlet("/CreateUserServlet")
public class CreateUserServlet extends HttpServlet {
	
	private static final long serialVersionUID = 1L;

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		
		String password = req.getParameter( "password" );
		String email = req.getParameter( "email" );
		User user = new User();
		user.setEmail( email );
		user.setPassword( new Sha256Hash( password ).toString() );
		
		UserDAO userdao = UserDAOImplementation.getInstance();
		userdao.create( user );
		
		resp.sendRedirect( req.getContextPath()  +"/LoginView.jsp");
	}
}
