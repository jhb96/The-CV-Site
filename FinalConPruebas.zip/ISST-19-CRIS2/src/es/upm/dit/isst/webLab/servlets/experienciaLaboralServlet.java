package es.upm.dit.isst.webLab.servlets;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;

import es.upm.dit.isst.webLab.dao.ExperienciaLaboralDAO;
import es.upm.dit.isst.webLab.dao.ExperienciaLaboralDAOImplementation;
import es.upm.dit.isst.webLab.dao.UserDAO;
import es.upm.dit.isst.webLab.dao.UserDAOImplementation;
import es.upm.dit.isst.webLab.model.ExperienciaLaboral;


@MultipartConfig
@WebServlet({ "/experienciaLaboral" })
public class experienciaLaboralServlet extends HttpServlet {
	
	private static final long serialVersionUID = 1L;


	@Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {
    	
    		getServletContext().getRequestDispatcher( "/cvInfoView.jsp" ).forward( req, resp );
    		
    }
	
	
	  @Override
	    protected void doPost(HttpServletRequest req, HttpServletResponse resp)
	            throws ServletException, IOException {
		  
		  
		 
		  	String email = req.getParameter("email");
		  	String puesto = req.getParameter("Puesto");
		  	String empresa = req.getParameter("Empresa");
		  	String descripcion = req.getParameter("Descripci�n");
		  	
			//CERTIFICADO (FILE)
			Part filePart = req.getPart("Certificado");
			InputStream fileContent = filePart.getInputStream();
			ByteArrayOutputStream output = new ByteArrayOutputStream();
			byte[] buffer = new byte[10240];
			for (int length = 0; (length = fileContent.read(buffer)) > 0;) output.write(buffer, 0, length);

			//Fechas
			String comienzostr = req.getParameter("Comienzo");
			SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
			Date comienzo = null;
			try {
				comienzo = sdf.parse(comienzostr);
			} catch (ParseException e) {
				e.printStackTrace();
			}
			
			String finalizacionstr = req.getParameter("Finalizacion");
			SimpleDateFormat sdff = new SimpleDateFormat("yyyy-MM-dd");
			Date finalizacion = null;
			try {
				finalizacion = sdff.parse(finalizacionstr);
			} catch (ParseException e) {
				e.printStackTrace();
			}
			
			Boolean actualmente = req.getParameter("actually") != null;
			
			UserDAO udao = UserDAOImplementation.getInstance();
			ExperienciaLaboralDAO expdao = ExperienciaLaboralDAOImplementation.getInstance();		
						
			ExperienciaLaboral experiencia = new ExperienciaLaboral();
			
			experiencia.setEmpresa(empresa);
			experiencia.setPuesto(puesto);
			experiencia.setfechaInicio(comienzo);
			experiencia.setFechaFin(finalizacion);
			experiencia.setActualmente(actualmente);
			experiencia.setCertificado(output.toByteArray());
			experiencia.setUserForm(udao.read(email)); 
			experiencia.setEmail(email);
			experiencia.setDescripci�n(descripcion);

			expdao.create(experiencia);
			expdao.read(email).forEach(ExperienciaLaboral -> System.out.println(ExperienciaLaboral.getPuesto()));
			req.getSession().setAttribute("experiencialaboral", expdao.read(email));
			
			getServletContext().getRequestDispatcher( "/cvInfoView.jsp" ).forward( req, resp );

	    }
}
