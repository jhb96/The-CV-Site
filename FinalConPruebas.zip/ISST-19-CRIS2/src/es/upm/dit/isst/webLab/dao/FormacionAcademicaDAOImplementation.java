package es.upm.dit.isst.webLab.dao;

import es.upm.dit.isst.webLab.model.Formaci�nAcad�mica;

import java.util.ArrayList;
import java.util.Collection;

import javax.persistence.Query;

import org.hibernate.Session;


public class FormacionAcademicaDAOImplementation implements FormacionAcademicaDAO{
	
	private static FormacionAcademicaDAOImplementation instancia = null;

	private FormacionAcademicaDAOImplementation() {
	}

	public static FormacionAcademicaDAOImplementation getInstance() {
		if (null == instancia)
			instancia = new FormacionAcademicaDAOImplementation();
		return instancia;
	}

	@Override
	public void create(Formaci�nAcad�mica form) {
		Session session = SessionFactoryService.get().openSession();
		try {
			session.beginTransaction();
			session.save(form);
			session.getTransaction().commit();
		} catch (Exception e) {

		} finally {
			session.close();
		}		
	}

	@Override
	public Collection<Formaci�nAcad�mica> read(String email) {
		Session session = SessionFactoryService.get().openSession();
		Collection<Formaci�nAcad�mica> form = new ArrayList<Formaci�nAcad�mica>();
		try {
			session.beginTransaction();
			String query = "from Formaci�nAcad�mica WHERE EMAIL = '" + email + "'";
			form = session.createQuery(query).list();
			session.getTransaction().commit();
		} catch (Exception e) {

		} finally {
			session.close();
		}		
		return form;
	}

	@Override
	public void update(Formaci�nAcad�mica form) {
		Session session = SessionFactoryService.get().openSession();
		try {
			session.beginTransaction();
			session.saveOrUpdate(form);
			session.getTransaction().commit();
		} catch (Exception e) {

		} finally {
			session.close();
		}		
	}

	@Override
	public void delete(Formaci�nAcad�mica form) {
		Session session = SessionFactoryService.get().openSession();
		try {
			session.beginTransaction();
			session.delete(form);
			session.getTransaction().commit();
		} catch (Exception e) {

		} finally {
			session.close();
		}		
	}

	@SuppressWarnings({ "finally", "unchecked" })
	@Override
	public Collection<Formaci�nAcad�mica> readAll() {
		Session session = SessionFactoryService.get().openSession();
		Collection<Formaci�nAcad�mica> forms = null;
		try {
			session.beginTransaction();
			forms = session.createQuery("from Formaci�nAcad�mica").list();
			System.out.println(forms);
			session.getTransaction().commit();
		} catch (Exception e) {

		} finally {
			session.close();
			return forms;
		}
	}
	
	
	public void delete(Integer idForm) {
		Session session = SessionFactoryService.get().openSession();
		try {
			session.beginTransaction();
			String query = "delete Formaci�nAcad�mica WHERE idForm = '" + idForm+"'";
			Query q = session.createQuery(query);
			q.executeUpdate();
			session.getTransaction().commit();
		} catch (Exception e) {

		} finally {
			session.close();
		}		
		return ;
	}
	
	
}
