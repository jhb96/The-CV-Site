package es.upm.dit.isst.webLab.servlets;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.itextpdf.io.font.constants.StandardFonts;
import com.itextpdf.kernel.font.PdfFont;
import com.itextpdf.kernel.font.PdfFontFactory;
import com.itextpdf.kernel.pdf.PdfDocument;
import com.itextpdf.kernel.pdf.PdfWriter;
import com.itextpdf.layout.Document;
import com.itextpdf.layout.element.List;
import com.itextpdf.layout.element.ListItem;
import com.itextpdf.layout.element.Paragraph;
import com.itextpdf.layout.element.Text;
import com.itextpdf.layout.property.TextAlignment;

import es.upm.dit.isst.webLab.dao.UserDAO;
import es.upm.dit.isst.webLab.dao.UserDAOImplementation;
import es.upm.dit.isst.webLab.model.ExperienciaLaboral;
import es.upm.dit.isst.webLab.model.Formaci�nAcad�mica;
import es.upm.dit.isst.webLab.model.Idiomas;
import es.upm.dit.isst.webLab.model.Informaci�nB�sica;
import es.upm.dit.isst.webLab.model.Intereses;
import es.upm.dit.isst.webLab.model.User;

@WebServlet({ "/GenerarPDFServlet" })
public class GenerarPDFServlet extends HttpServlet {

	private static final long serialVersionUID = 1L;
	// public static String DEST =
	// "C:\\Users\\Albertoperez\\Desktop\\ISST-trabajo\\ejemplo"+
	// Math.floor(100*Math.random()) +".pdf";

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

		getServletContext().getRequestDispatcher("/exportCvView.jsp").forward(req, resp);

	}

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

		Boolean nombrecb = req.getParameter("nombrecb") != null;
		Boolean apellidoscb = req.getParameter("apellidoscb") != null;
		Boolean emailcb = req.getParameter("emailcb") != null;
		Boolean direccioncb = req.getParameter("direccioncb") != null;
		Boolean ciudadcb = req.getParameter("ciudadcb") != null;
		Boolean telefonocb = req.getParameter("telefonocb") != null;
		Boolean perfilcb = req.getParameter("perfilcb") != null;

		User user = new User();

		String home = System.getProperty("user.home");
		String desc = home + "/Downloads/MiCV.pdf";

		// String email = req.getParameter( "email" );
		String email = (String) req.getSession().getAttribute("email");
		System.out.println(email);

		UserDAO userdao = UserDAOImplementation.getInstance();
		user = userdao.read(email);

		Informaci�nB�sica ib = new Informaci�nB�sica();
		ib = (Informaci�nB�sica) req.getSession().getAttribute("informacionbasica");

		java.util.List<Formaci�nAcad�mica> listfa = (java.util.List<Formaci�nAcad�mica>) req.getSession()
				.getAttribute("formacionacademica");
		java.util.List<ExperienciaLaboral> listel = (java.util.List<ExperienciaLaboral>) req.getSession()
				.getAttribute("experiencialaboral");
		java.util.List<Idiomas> listidiomas = (java.util.List<Idiomas>) req.getSession().getAttribute("idiomas");
		java.util.List<Intereses> listint = (java.util.List<Intereses>) req.getSession().getAttribute("intereses");

		PdfWriter writer = new PdfWriter(desc);
		PdfDocument pdf = new PdfDocument(writer);
		Document doc = new Document(pdf);
		PdfFont font = PdfFontFactory.createFont(StandardFonts.TIMES_ROMAN);
		PdfFont bold = PdfFontFactory.createFont(StandardFonts.HELVETICA_BOLD);

		doc.add(new Paragraph("MI CV").setFont(font).setFontSize(30).setTextAlignment(TextAlignment.CENTER)
				.setUnderline());

		Paragraph p = new Paragraph();
		if (ib != null) {
			if (nombrecb == true) {
				Text p01 = new Text("nombre:").setFont(bold);
				Text p02 = new Text(ib.getNombre() + "\n").setFont(font);
				p.add(p01).add(p02);
			}
			if (apellidoscb == true) {
				Text p03 = new Text("Apellidos: ").setFont(bold);
				Text p04 = new Text(ib.getApellidos() + "\n").setFont(font);
				p.add(p03).add(p04);
			}
			if (emailcb == true) {
				Text p05 = new Text("Email: ").setFont(bold);
				Text p06 = new Text(ib.getEmail() + "\n").setFont(font);
				p.add(p05).add(p06);
			}
			if (direccioncb == true) {
				Text p07 = new Text("Direccion: ").setFont(bold);
				Text p08 = new Text(ib.getDirecci�n() + "\n").setFont(font);
				p.add(p07).add(p08);
			}
			if (ciudadcb == true) {
				Text p09 = new Text("ciudad: ").setFont(bold);
				Text p010 = new Text(ib.getCiudad() + "\n").setFont(font);
				p.add(p09).add(p010);
			}
			if (telefonocb == true) {
				Text p011 = new Text("Tel�fono: ").setFont(bold);
				Text p012 = new Text(ib.getTel�fono() + "\n").setFont(font);
				p.add(p011).add(p012);
			}
			if (perfilcb == true) {
				Text p013 = new Text("Perfil: ").setFont(bold);
				Text p014 = new Text(ib.getPerfil() + "\n").setFont(font);
				p.add(p013).add(p014);
			}
		}

		Paragraph p1 = new Paragraph();
		for (Formaci�nAcad�mica fa : listfa) {
			Boolean facb = false;
			facb = req.getParameter(fa.getTitulaci�n() + "cb") != null;
			if (facb == true) {
				Text p11 = new Text(" - Titulaci�n: ").setFont(bold);
				Text p12 = new Text(fa.getTitulaci�n() + "\n").setFont(font);
				Text p13 = new Text("Centro: ").setFont(bold);
				Text p14 = new Text(fa.getCentro() + "\n").setFont(font);
				Text p15 = new Text("Comienzo: ").setFont(bold);
				Text p16 = new Text(fa.getFechaComienzo() + "\n").setFont(font);
				Text p17 = new Text("Finalizaci�n: ").setFont(bold);
				Text p18 = new Text(fa.getFechaFin() + "\n");
				p1.add(p11).add(p12).add(p13).add(p14).add(p15).add(p16).add(p17).add(p18);
				facb = false;
			}

		}

		Paragraph p2 = new Paragraph();
		for (ExperienciaLaboral el : listel) {
			Boolean elcb = false;
			elcb = req.getParameter(el.getPuesto() + "cb") != null;
			if (elcb == true) {
				Text p21 = new Text("- Puesto: ").setFont(bold);
				Text p22 = new Text(el.getPuesto() + "\n").setFont(font);
				Text p23 = new Text("Empresa: ").setFont(bold);
				Text p24 = new Text(el.getEmpresa() + "\n").setFont(font);
				Text p25 = new Text("Comienzo: ").setFont(bold);
				Text p26 = new Text(el.getFechaInicio() + "\n").setFont(font);
				Text p27 = new Text("Finalizaci�n: ").setFont(bold);
				Text p28 = new Text(el.getFechaFin() + "\n").setFont(font);
				p2.add(p21).add(p22).add(p23).add(p24).add(p25).add(p26).add(p27).add(p28);
				elcb = false;
			}

		}

		Paragraph p3 = new Paragraph();
		for (Idiomas i : listidiomas) {
			Boolean icb = false;
			icb = req.getParameter(i.getIdioma() + "cb") != null;
			if (icb == true) {
				Text p31 = new Text("- Idioma: ").setFont(bold);
				Text p32 = new Text(i.getIdioma() + "\n").setFont(font);
				Text p33 = new Text("Nivel: ").setFont(bold);
				Text p34 = new Text(i.getNivel() + "\n").setFont(font);
				Text p35 = new Text("Capacidad: ").setFont(bold);
				Text p36 = new Text(i.getCapacidad() + "\n").setFont(font);
				p3.add(p31).add(p32).add(p33).add(p34).add(p35).add(p36);
			}
			icb = false;
		}

		Paragraph p4 = new Paragraph();
		for (Intereses in : listint) {
			Boolean incb = false;
			incb = req.getParameter(in.getDescripci�n() + "cb") != null;
			if (incb == true) {
				Text p41 = new Text("- Habilidad: ").setFont(bold);
				Text p42 = new Text(in.getTipoSecci�n() + "\n").setFont(font);
				Text p43 = new Text("Descripci�n: ").setFont(bold);
				Text p44 = new Text(in.getDescripci�n() + "\n").setFont(font);
				p4.add(p41).add(p42).add(p43).add(p44);
				incb = false;
			}

		}

		List list = new List().setSymbolIndent(12).setListSymbol("\u2022").setFont(font).setFontSize(20);
		List list1 = new List().setSymbolIndent(12).setListSymbol("\u2022").setFont(font).setFontSize(20);
		List list2 = new List().setSymbolIndent(12).setListSymbol("\u2022").setFont(font).setFontSize(20);
		List list3 = new List().setSymbolIndent(12).setListSymbol("\u2022").setFont(font).setFontSize(20);
		List list4 = new List().setSymbolIndent(12).setListSymbol("\u2022").setFont(font).setFontSize(20);
		list.add(new ListItem("Informacion b�sica"));
		list1.add(new ListItem("Formaci�n Acad�mica"));
		list2.add(new ListItem("Experiencia Laboral"));
		list3.add(new ListItem("Idiomas"));
		list4.add(new ListItem("Intereses"));

		doc.add(list);
		doc.add(p);
		doc.add(list1);
		doc.add(p1);
		doc.add(list2);
		doc.add(p2);
		doc.add(list3);
		doc.add(p3);
		doc.add(list4);
		doc.add(p4);
		doc.close();

		resp.sendRedirect(req.getContextPath() + "/exportCvView.jsp");
	}

}
