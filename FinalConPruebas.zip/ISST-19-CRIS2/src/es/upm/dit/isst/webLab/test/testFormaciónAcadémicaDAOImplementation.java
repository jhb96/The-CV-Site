package es.upm.dit.isst.webLab.test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;
import static org.junit.jupiter.api.Assertions.*;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import es.upm.dit.isst.webLab.dao.FormacionAcademicaDAO;
import es.upm.dit.isst.webLab.dao.FormacionAcademicaDAOImplementation;
import es.upm.dit.isst.webLab.model.ExperienciaLaboral;
import es.upm.dit.isst.webLab.model.Formaci�nAcad�mica;

class testFormaci�nAcad�micaDAOImplementation {

	
	private Date fecha;
	private FormacionAcademicaDAO form;
	private String email = "guillermo@gmail.com";
	private Formaci�nAcad�mica formacion1;
	private Formaci�nAcad�mica formacion2;

	
	@BeforeEach
	void setUp() throws Exception {		
		form  = FormacionAcademicaDAOImplementation.getInstance();
		
		//Fechas
		SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-yyyy");
		fecha = null;
		try {
			fecha = sdf.parse("10-10-2010");
		} catch (ParseException e) {
			e.printStackTrace();
		}
		formacion1 = new Formaci�nAcad�mica("teleco", "upm", null, fecha, fecha, false);
		formacion2 = new Formaci�nAcad�mica("Master de teleco", "upm", null, fecha, fecha, true);
		formacion1.setEmail(email);
		formacion2.setEmail(email);
		
	}

	@AfterEach
	void tearDown() throws Exception {
		try {
			form.delete(formacion1);
			form.delete(formacion2);
		} catch(Exception e) {}
	}

	
	@Test
	void testCreate() {
	
		form.create(formacion1);
		form.create(formacion2);
				
		List<Formaci�nAcad�mica> form1Test = (List) form.read(email);
		
		assertEquals("Se guardaron los dos objetos??", 2, form1Test.size());
		assertEquals("El form 1 se guard� bien?", formacion1.getTitulaci�n(), form1Test.get(0).getTitulaci�n());
		assertEquals("El form 2 se guard� bien?", formacion2.getTitulaci�n(), form1Test.get(1).getTitulaci�n());

	}
	
	@Test
	void testRead() {
		
		assertEquals("Carga una lista vac�a si no hay objetos??", 0, form.read(email).size());

		form.create(formacion1);
		form.create(formacion2);
		
		List<Formaci�nAcad�mica> form1Test = (List) form.read(email);
		
		assertNotNull("Funciona la funci�n cargar?",form1Test);
		assertEquals("Se guardaron los dos objetos??", 2, form1Test.size());
		assertEquals("El form 1 se carga bien?", formacion1.getTitulaci�n(), form1Test.get(0).getTitulaci�n());
		assertEquals("El form 2 se carga bien?", formacion2.getTitulaci�n(), form1Test.get(1).getTitulaci�n());

	}
	
	@Test
	void testDelete() {
		
		form.create(formacion1);
		form.create(formacion2);
		
		List<Formaci�nAcad�mica> form1Test = (List) form.read(email);
		
		assertEquals("Se guardaron los dos objetos??", 2, form1Test.size());
		
		form.delete(formacion2);
		form.delete(new Formaci�nAcad�mica());

		form1Test = (List) form.read(email);


		assertEquals("Se borr� el objeto bien?? Y no ocurri� nada al borrar un objeto que no est�?", 1, form1Test.size());
		assertNotEquals("Y el que queda no es el que borr�?", formacion2.getTitulaci�n(),form1Test.get(0).getTitulaci�n());
		
		
	}
	
	@Test
	void testReadAll() {
	//No lo usamos
	}
	
	@Test
	void testUpdate() {
		
		form.create(formacion1);
		form.create(formacion2);
		
		List<Formaci�nAcad�mica> form1Test = (List) form.read(email);
		
		assertEquals("Se guardaron los dos objetos??", 2, form1Test.size());
		
		formacion2.setTitulaci�n("M�ster en biom�dicas");
		form.update(formacion2);	
		
		form1Test = (List) form.read(email);
		String titulacionTest = form1Test.get(1).getTitulaci�n();
		
		assertEquals("Se actualiz� el objeto??", "M�ster en biom�dicas", titulacionTest);
	
	}

}

