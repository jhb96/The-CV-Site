package es.upm.dit.isst.webLab.servlets;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;

import es.upm.dit.isst.webLab.dao.FormacionAcademicaDAO;
import es.upm.dit.isst.webLab.dao.FormacionAcademicaDAOImplementation;
import es.upm.dit.isst.webLab.dao.UserDAO;
import es.upm.dit.isst.webLab.dao.UserDAOImplementation;
import es.upm.dit.isst.webLab.model.Formaci�nAcad�mica;

@MultipartConfig
@WebServlet({ "/formacionAcademica" })
public class formacionAcademicaServlet extends HttpServlet {

	private static final long serialVersionUID = 1L;



	
	
	  @Override
	    protected void doPost(HttpServletRequest req, HttpServletResponse resp)
	            throws ServletException, IOException {
		  
		  
	
		  	String email = req.getParameter("email");
		  	System.out.println("Es el email?" + email);
			String titulacion = req.getParameter( "Titulacion" );
			String centro = req.getParameter( "Centro" );
	
			
			
			//CERTIFICADO 
			Part filePart = req.getPart("Certificado");
			InputStream fileContent = filePart.getInputStream();
			ByteArrayOutputStream output = new ByteArrayOutputStream();
			byte[] buffer = new byte[10240];
			for (int length = 0; (length = fileContent.read(buffer)) > 0;) output.write(buffer, 0, length);
			
			
			String comienzostr = req.getParameter("Comienzo");
			SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
			Date comienzo = null;
			try {
				comienzo = sdf.parse(comienzostr);
			} catch (ParseException e) {
				e.printStackTrace();
			}
			
			String finalizacionstr = req.getParameter("Finalizacion");
			SimpleDateFormat sdff = new SimpleDateFormat("yyyy-MM-dd");
			Date finalizacion = null;
			try {
				finalizacion = sdff.parse(finalizacionstr);
			} catch (ParseException e) {
				e.printStackTrace();
			}
			
			Boolean actualmente = req.getParameter("actually")!=null;
			

			
			UserDAO udao = UserDAOImplementation.getInstance();		
			
			Formaci�nAcad�mica formAcademica = new Formaci�nAcad�mica();
			formAcademica.setTitulaci�n(titulacion);
			formAcademica.setActualmente(actualmente);
			formAcademica.setCentro(centro);
			formAcademica.setFechaComienzo(comienzo);
			formAcademica.setFechaFin(finalizacion);
			formAcademica.setCertificado(output.toByteArray());
			formAcademica.setUserForm(udao.read(email)); //LO RELACIONA CON SU USER
			formAcademica.setEmail(email);
		
			
			FormacionAcademicaDAO formdao = FormacionAcademicaDAOImplementation.getInstance();
			formdao.create(formAcademica);
			
			
			formdao.read(email).forEach(Formaci�nAcad�mica -> System.out.println(Formaci�nAcad�mica.getCentro()));
			req.getSession().setAttribute("formacionacademica", formdao.read(email));
		
			getServletContext().getRequestDispatcher("/cvInfoView.jsp").forward( req, resp );

	    }
}
