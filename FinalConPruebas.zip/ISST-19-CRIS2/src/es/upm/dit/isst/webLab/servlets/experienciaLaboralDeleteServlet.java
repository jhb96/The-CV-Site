package es.upm.dit.isst.webLab.servlets;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import es.upm.dit.isst.webLab.dao.ExperienciaLaboralDAO;
import es.upm.dit.isst.webLab.dao.ExperienciaLaboralDAOImplementation;


@WebServlet("/experienciaLaboralDelete")
public class experienciaLaboralDeleteServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
   
    public experienciaLaboralDeleteServlet() {
        super();

    }


	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		ExperienciaLaboralDAO expdao = ExperienciaLaboralDAOImplementation.getInstance();
		String email = (String) request.getSession().getAttribute("email");
		Integer id =  (int) Long.parseLong(request.getParameter("idExp"));
		System.out.println("La id es:" +id);
		System.out.println("La email es:" +email);
		expdao.delete(id);
		expdao.read(email).forEach(ExperienciaLaboral -> System.out.println(ExperienciaLaboral.getPuesto()));
		request.getSession().setAttribute("experiencialaboral", expdao.read(email));
		getServletContext().getRequestDispatcher("/userInfoView.jsp").forward(request, response);
	}

}
