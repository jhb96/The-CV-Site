package es.upm.dit.isst.webLab.servlets;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import es.upm.dit.isst.webLab.dao.ExperienciaLaboralDAO;
import es.upm.dit.isst.webLab.dao.ExperienciaLaboralDAOImplementation;
import es.upm.dit.isst.webLab.dao.FormacionAcademicaDAO;
import es.upm.dit.isst.webLab.dao.FormacionAcademicaDAOImplementation;
import es.upm.dit.isst.webLab.dao.IdiomasDAO;
import es.upm.dit.isst.webLab.dao.IdiomasDAOImplementation;
import es.upm.dit.isst.webLab.dao.InteresesDAO;
import es.upm.dit.isst.webLab.dao.InteresesDAOImplementation;
import es.upm.dit.isst.webLab.dao.UserDAO;
import es.upm.dit.isst.webLab.dao.UserDAOImplementation;
import es.upm.dit.isst.webLab.model.Informaci�nB�sica;
import es.upm.dit.isst.webLab.model.User;

@WebServlet("/UserServlet")
public class UserServlet extends HttpServlet {

	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

		UserDAO userdao = UserDAOImplementation.getInstance();
		String email = req.getParameter("email");
		req.getSession().setAttribute("user", userdao.read(email));
		req.getSession().setAttribute("email", email);

		UserDAO udao = UserDAOImplementation.getInstance();
		User userActivo = udao.read(email);
		System.out.println(email);
		Informaci�nB�sica infobasica = new Informaci�nB�sica();
		infobasica = userActivo.getInformaci�nB�sica();
		req.getSession().setAttribute("informacionbasica", infobasica);

		FormacionAcademicaDAO formdao = FormacionAcademicaDAOImplementation.getInstance();
		formdao.read(email).forEach(Formaci�nAcad�mica -> System.out.println(Formaci�nAcad�mica.getCentro()));
		req.getSession().setAttribute("formacionacademica", formdao.read(email));
		
		ExperienciaLaboralDAO expdao = ExperienciaLaboralDAOImplementation.getInstance();
		expdao.read(email).forEach(ExperienciaLaboral -> System.out.println(ExperienciaLaboral.getPuesto()));
		req.getSession().setAttribute("experiencialaboral", expdao.read(email));

		IdiomasDAO idiomdao = IdiomasDAOImplementation.getInstance();
		idiomdao.read(email).forEach(Idiomas -> System.out.println(Idiomas.getIdioma()));
		req.getSession().setAttribute("idiomas", idiomdao.read(email));
		
		InteresesDAO intdao = InteresesDAOImplementation.getInstance();
		intdao.read(email).forEach(Intereses -> System.out.println(Intereses.getTipoSecci�n()));
		req.getSession().setAttribute("intereses", intdao.read(email));
		
		
		getServletContext().getRequestDispatcher("/InicioView.jsp").forward(req, resp);
	}
}
