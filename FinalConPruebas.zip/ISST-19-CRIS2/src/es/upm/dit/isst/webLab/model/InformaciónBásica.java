package es.upm.dit.isst.webLab.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.PrimaryKeyJoinColumn;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;

@Entity
@Table(name = "INFORMACIONBASICA", uniqueConstraints = {
		@UniqueConstraint(columnNames = "infoID")})
		//@UniqueConstraint(columnNames = "EMAIL")})
public class Informaci�nB�sica implements Serializable {

	private static final long serialVersionUID = 1L;



	@Id
	@PrimaryKeyJoinColumn
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "infoID", unique = true, nullable = true)
	private Integer infoID; //FOREING KEY = PRIMARY KEY
	
	
	
	@Column(name = "NAME", unique = false, nullable = true)
	private String nombre;
	@Column(name = "SURNAME", unique = false, nullable = true)
	private String apellidos;
	@Column(name = "EMAIL", unique = false, nullable = true)
	private String email;
	@Column(name = "ADDRESS", unique = false, nullable = true)
	private String direcci�n;
	@Column(name = "CITY", unique = false, nullable = true)
	private String ciudad;
	@Column(name = "TELEPHONE", unique = false, nullable = true)
	private String tel�fono;
	@Column(name = "PROFILE", unique = false, nullable = true, length = 535 )
	private String perfil;
	
	public Informaci�nB�sica() {}
	
	public Informaci�nB�sica(String nombre, String apellidos, String email, String direcci�n, String ciudad,
			String tel�fono, String perfil) {
			
			this.nombre = nombre;
			this.apellidos = apellidos;
			this.email = email;
			this.direcci�n = direcci�n;
			this.ciudad = ciudad;
			this.tel�fono = tel�fono;
			this.perfil = perfil;
		
	}
	
	
	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre= nombre;
	}
	
	public String getApellidos() {
		return apellidos;
	}

	public void setApellidos(String apellidos) {
		this.apellidos = apellidos;
	}
	
	
	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email= email;
	}
	
	
	public String getDirecci�n() {
		return direcci�n;
	}

	public void setDirecci�n(String direcci�n) {
		this.direcci�n = direcci�n;
	}
	
	
	public String getCiudad() {
		return ciudad;
	}

	public void setCiudad(String ciudad) {
		this.ciudad = ciudad;
	}
	
	
	public String getTel�fono() {
		return tel�fono;
	}

	public void setTel�fono(String tel�fono) {
		this.tel�fono = tel�fono;
	}
	
	
	public String getPerfil() {
		return perfil;
	}

	public void setPerfil(String perfil) {
		this.perfil = perfil;
	}
	
}
