package es.upm.dit.isst.webLab.model;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.*;

@Entity
@Table(name = "EXPERIENCIALABORAL", uniqueConstraints = {
		@UniqueConstraint(columnNames = "idExp")})
public class ExperienciaLaboral implements Serializable{
	
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "idExp", unique = true, nullable = true)
	private Integer idExp;
	
	@ManyToOne
	private User userForm;//Identifica el usuario al que pertenece la experiencia

	private String email; //Identifica el usuario por el email
	 
	
	private String puesto;
	
	
	private String empresa;
	
	@Lob
	private byte[] certificado;
	
	
	private Date fechaInicio;
	
	
	private Date fechaFin;
	
	
	private Boolean actualmente;
	
	
	private String descripci�n;
	
		
	public ExperienciaLaboral() {}
	
	public ExperienciaLaboral(String puesto, String empresa, Date fechaInicio, Date fechaFin,
			Boolean actualmente, String descripci�n) {
		
			this.puesto = puesto;
			this.empresa = empresa;
			this.fechaInicio = fechaInicio;
			this.fechaFin = fechaFin;
			this.actualmente = actualmente;
			this.descripci�n = descripci�n;
		
	}
	
	public String getPuesto() {
		return puesto;
	}

	public void setPuesto(String puesto) {
		this.puesto = puesto;
	}
	
	
	public String getEmpresa() {
		return empresa;
	}

	public void setEmpresa(String empresa) {
		this.empresa = empresa;
	}
	
	
	public Date getFechaInicio() {
		return fechaInicio;
	}

	public void setfechaInicio(Date fechaInicio) {
		this.fechaInicio = fechaInicio;
	}
	
	
	public Date getFechaFin() {
		return fechaFin;
	}

	public void setFechaFin(Date fechaFin) {
		this.fechaFin = fechaFin;
	}
	
	
	public Boolean getActualmente() {
		return actualmente;
	}

	public void setActualmente(Boolean actualmente) {
		this.actualmente = actualmente;
	}
	
	
	public String getDescripci�n() {
		return descripci�n;
	}

	public void setDescripci�n(String descripci�n) {
		this.descripci�n = descripci�n;
	}

	public byte[] getCertificado() {
		return certificado;
	}

	public void setCertificado(byte[] certificado) {
		this.certificado = certificado;
	}
	

	public User getUserForm() {
		return userForm;
	}

	public void setUserForm(User user) {
		this.userForm = user;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}
	public Integer getidExp() {
		return idExp;
	}
	
	
}
