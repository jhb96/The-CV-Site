package es.upm.dit.isst.webLab.dao;

import java.util.ArrayList;
import java.util.Collection;

import javax.persistence.Query;

import es.upm.dit.isst.webLab.model.ExperienciaLaboral;
import org.hibernate.Session;

public class ExperienciaLaboralDAOImplementation implements ExperienciaLaboralDAO {

	private static ExperienciaLaboralDAOImplementation instancia = null;

	private ExperienciaLaboralDAOImplementation() {
	}

	public static ExperienciaLaboralDAOImplementation getInstance() {
		if (null == instancia)
			instancia = new ExperienciaLaboralDAOImplementation();
		return instancia;
	}

	@Override
	public void create(ExperienciaLaboral exp) {
		Session session = SessionFactoryService.get().openSession();
		try {
			session.beginTransaction();
			session.save(exp);
			session.getTransaction().commit();
		} catch (Exception e) {

		} finally {
			session.close();
		}	
		
	}

	@Override
	public Collection<ExperienciaLaboral> read(String email) {
		Session session = SessionFactoryService.get().openSession();
		Collection<ExperienciaLaboral> exp = new ArrayList<ExperienciaLaboral>();
		try {
			session.beginTransaction();
			String query ="from ExperienciaLaboral WHERE EMAIL = '" + email + "'";
			exp=session.createQuery(query).list();
			session.getTransaction().commit();
		} catch (Exception e) {

		} finally {
			session.close();
		}		return exp;
	}

	@Override
	public void update(ExperienciaLaboral exp) {
		Session session = SessionFactoryService.get().openSession();
		try {
			session.beginTransaction();
			session.saveOrUpdate(exp);
			session.getTransaction().commit();
		} catch (Exception e) {

		} finally {
			session.close();
		}	
	}

	@Override
	public void delete(ExperienciaLaboral exp) {
		Session session = SessionFactoryService.get().openSession();
		try {
			session.beginTransaction();
			session.delete(exp);
			session.getTransaction().commit();
		} catch (Exception e) {

		} finally {
			session.close();
		}
	}

	@Override
	@SuppressWarnings({ "unchecked", "finally" })
	public Collection<ExperienciaLaboral> readAll() {
		Session session = SessionFactoryService.get().openSession();
		Collection<ExperienciaLaboral> exps = null;
		try {
			session.beginTransaction();
			exps = session.createQuery("from ExperienciaLaboral").list();
			session.getTransaction().commit();
		} catch (Exception e) {

		} finally {
			session.close();
			return exps;
		}
	}
	public void delete(Integer id) {
		Session session = SessionFactoryService.get().openSession();
		try {
			session.beginTransaction();
			String query = "delete ExperienciaLaboral WHERE idExp = '" + id+"'";
			Query q = session.createQuery(query);
			q.executeUpdate();
			session.getTransaction().commit();
		} catch (Exception e) {

		} finally {
			session.close();
		}		
		return ;
	}
	
}
