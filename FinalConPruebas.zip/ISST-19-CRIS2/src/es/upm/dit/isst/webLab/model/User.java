package es.upm.dit.isst.webLab.model;

import java.io.Serializable;
import java.util.List;

import javax.persistence.*;

@Entity
@Table(name = "USER", uniqueConstraints = {@UniqueConstraint(columnNames = "EMAIL")})
public class User implements Serializable {

	private static final long serialVersionUID = 1L;


	@Id
	@Column(name = "EMAIL", unique = true, nullable = false)
	private String email;  
	
	@Column(name = "PASSWORD", unique = false, nullable = false)
	private String password;
	
	@OneToOne(cascade=CascadeType.ALL)
	
	private Informaci�nB�sica infoBasica; 
	
	
	@OneToMany
	private List<Formaci�nAcad�mica> formacionAcademica;
	
	@OneToMany
	private List<ExperienciaLaboral> experiencia;
	
	@OneToMany
	private List<Idiomas> idiomas;

	@OneToMany
	private List<Intereses> intereses;
	
	

	
	
	public User () {}
	public User (Integer id,String email,String password,Informaci�nB�sica infoBasic,List<Formaci�nAcad�mica> formacionAcademica,
			List<Intereses> intereses, List<Idiomas> idiomas, List<ExperienciaLaboral> experiencia) {
		//this.id=id;
		this.email = email;
		this.password = password;
		//this.infoID = infoBasic;
		this.formacionAcademica = formacionAcademica;
		this.intereses = intereses;
		this.idiomas = idiomas;
		this.experiencia=experiencia;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public Informaci�nB�sica getInformaci�nB�sica() {
		return infoBasica;
	}
	
	public void setInformaci�nB�sica(Informaci�nB�sica infoB�sica) {
		this.infoBasica = infoB�sica;
	}
	

	public List<Formaci�nAcad�mica> getFormaci�nAcad�mica() {
		return formacionAcademica;
	}
	
	public void setFormaci�nAcad�mica(List<Formaci�nAcad�mica> formacionAcademica) {
		this.formacionAcademica = formacionAcademica;
	}
	
	public void addFormaci�nAcad�mica(Formaci�nAcad�mica formacionAcademica) {
		this.formacionAcademica.add(formacionAcademica);
	}

}
