package es.upm.dit.isst.webLab.servlets;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import es.upm.dit.isst.webLab.dao.FormacionAcademicaDAO;
import es.upm.dit.isst.webLab.dao.FormacionAcademicaDAOImplementation;
import es.upm.dit.isst.webLab.dao.IdiomasDAO;
import es.upm.dit.isst.webLab.dao.IdiomasDAOImplementation;


@WebServlet("/idiomasDelete")
public class idiomasDeleteServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    public idiomasDeleteServlet() {
        super();
    }


	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		IdiomasDAO idiomdao = IdiomasDAOImplementation.getInstance();
		String email = (String)  request.getSession().getAttribute("email");
		Integer id =  (int) Long.parseLong(request.getParameter("idiomid"));
		System.out.println("La id es:" +id);
		System.out.println("La email es:" +email);
		idiomdao.delete(id);
		
		idiomdao.read(email).forEach(Idiomas -> System.out.println(Idiomas.getIdioma()));
		request.getSession().setAttribute("idiomas", idiomdao.read(email));
	
		 getServletContext().getRequestDispatcher("/userInfoView.jsp").forward( request, response );
	}

}
