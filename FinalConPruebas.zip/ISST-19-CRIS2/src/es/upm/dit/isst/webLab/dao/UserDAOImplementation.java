package es.upm.dit.isst.webLab.dao;

import java.util.Collection;

import org.hibernate.Session;

import es.upm.dit.isst.webLab.model.User;


public class UserDAOImplementation implements UserDAO {
	private static UserDAOImplementation instancia = null;

	private UserDAOImplementation() {
	}

	public static UserDAOImplementation getInstance() {
		if (null == instancia)
			instancia = new UserDAOImplementation();
		return instancia;
	}

	@Override
	public void create(User user) {
		Session session = SessionFactoryService.get().openSession();
		try {
			session.beginTransaction();
			session.save(user);
			session.getTransaction().commit();
		} catch (Exception e) {

		} finally {
			session.close();
		}
	}

	@Override
	public void delete(User user) {
		Session session = SessionFactoryService.get().openSession();
		try {
			session.beginTransaction();
			session.delete(user);
			session.getTransaction().commit();
		} catch (Exception e) {

		} finally {
			session.close();
		}
	}

	@SuppressWarnings("finally")
	@Override
	public User read(String email) {
		Session session = SessionFactoryService.get().openSession();
		User user = new User();
		try {
			session.beginTransaction();
			user = session.load(User.class, email);
			session.getTransaction().commit();
		} catch (Exception e) {

		} finally {
			session.close();
			return user;

		}
	}

	@SuppressWarnings({ "unchecked", "finally" })
	@Override
	public Collection<User> readAll() {
		Session session = SessionFactoryService.get().openSession();
		Collection<User> users = null;
		try {
			session.beginTransaction();
			users = session.createQuery("from User").list();
			System.out.println(users);
			session.getTransaction().commit();
		} catch (Exception e) {

		} finally {
			session.close();
			return users;
		}

	}

	@Override
	public void update(User user) {
		Session session = SessionFactoryService.get().openSession();
		try {
			session.beginTransaction();
			session.saveOrUpdate(user);
			session.getTransaction().commit();
		} catch (Exception e) {

		} finally {
			session.close();
		}
	}

}