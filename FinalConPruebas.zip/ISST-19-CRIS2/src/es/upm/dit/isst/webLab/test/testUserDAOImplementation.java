package es.upm.dit.isst.webLab.test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;
import static org.junit.jupiter.api.Assertions.*;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.junit.BeforeClass;
import org.junit.FixMethodOrder;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.runners.MethodSorters;

import es.upm.dit.isst.webLab.dao.UserDAO;
import es.upm.dit.isst.webLab.dao.UserDAOImplementation;
import es.upm.dit.isst.webLab.model.ExperienciaLaboral;
import es.upm.dit.isst.webLab.model.Formaci�nAcad�mica;
import es.upm.dit.isst.webLab.model.Idiomas;
import es.upm.dit.isst.webLab.model.Informaci�nB�sica;
import es.upm.dit.isst.webLab.model.Intereses;
import es.upm.dit.isst.webLab.model.User;
import javassist.bytecode.ByteArray;


public class testUserDAOImplementation {
	
	private UserDAO udao;
	private User user1;
	private User user2;


	

	@BeforeEach
	void setUp() throws Exception {
		byte[] doc = new byte[2];
				
		SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-yyyy");
		Date comienzo = null;
		try {
			comienzo = sdf.parse("10-10-2014");
		} catch (ParseException e) {
			e.printStackTrace();
		}
		udao = UserDAOImplementation.getInstance();
		
		user1 = new User();
		user2 = new User();
		
		user1.setEmail("pepe@gmail.com");
		user1.setPassword("1234");
		user2.setEmail("juanjo@gmail.com");
		user2.setPassword("5678");
		
		
	}

	@AfterEach
	void tearDown() throws Exception {
		try {
			udao.delete(user1);
			udao.delete(user2);
		} catch(Exception e) {}
	}

	

	@Test
	void testCreate() {
		udao.create(user1);
		udao.create(user2);
		
		assertNotNull("Se ha guardado usuario 1?", udao.read(user1.getEmail()));
		assertNotNull("Se ha guardado usuario 2?", udao.read(user2.getEmail()));
		assertEquals("Guarda el usuario correctamente el email de 1?", udao.read(user1.getEmail()).getEmail(), user1.getEmail());
		assertEquals("Guarda el usuario correctamente el email de 2?", udao.read(user2.getEmail()).getEmail(), user2.getEmail());
		assertEquals("Guarda el usuario correctamente el password de 1?", udao.read(user1.getEmail()).getPassword(), user1.getPassword());
		assertEquals("Guarda el usuario correctamente el password de 2?", udao.read(user2.getEmail()).getPassword(), user2.getPassword());
		
	}


	@Test
	void testRead() {
		
		UserDAO udao = UserDAOImplementation.getInstance();
		udao.create(user1);
		udao.create(user2);
		
		
		//assertNull("Se carga un usuario que no est�??", udao.read("invalido@gmail.com"));
		assertNotNull("Se ha cargado usuario 1?", udao.read(user1.getEmail()));
		assertNotNull("Se ha cargado usuario 2?", udao.read(user2.getEmail()));
		assertEquals("Lee el usuario correctamente el email de 1?", udao.read(user1.getEmail()).getEmail(), user1.getEmail());
		assertEquals("Lee el usuario correctamente el email de 2?", udao.read(user2.getEmail()).getEmail(), user2.getEmail());
		assertEquals("Lee el usuario correctamente el password de 1?", udao.read(user1.getEmail()).getPassword(), user1.getPassword());
		assertEquals("Lee el usuario correctamente el password de 2?", udao.read(user2.getEmail()).getPassword(), user2.getPassword());
		
	}

	
	@Test
	void testUpdate() {
		
		udao.create(user1);
		udao.create(user2);
		
		user2.setPassword("abcd");
		udao.update(user2);
		
	
		assertEquals("Se actualiza correctamente el password user2?", udao.read(user2.getEmail()).getPassword(), user2.getPassword());
		assertNotEquals("Se borra correctamente la antigua pass?",  udao.read(user2.getEmail()).getPassword(), "5678");
	}


	
	
	@Test
	void testDelete() {
		udao.create(user1);
		udao.create(user2);
		udao.delete(user2);
		//udao.delete(new User(null, null, null, null, null, null, null, null));
		//udao.delete(new User(1, "pepito@gmail.com", "12344", null, null, null, null, null));
		assertNotEquals("Borra el usuario???", user2.getEmail(), udao.read(user2.getEmail()));
		
	}
	
	
	@Test
	void testReadAll() {
		List<User> usuarios = (List) udao.readAll();
		assertEquals("Devuelve una lista vac�a si no hay usuarios�?", 0, usuarios.size());
		
		udao.create(user1);
		udao.create(user2);
		usuarios = (List) udao.readAll();

		assertEquals("El n�mero de usuarios almacenados es el correcto?", 2, usuarios.size());
		assertEquals("El usuario 1 es el correcto?", user1.getEmail(), usuarios.get(0).getEmail());
		assertEquals("El usuario 2 es el correcto?", user2.getEmail(), usuarios.get(1).getEmail());

	}
}
