package es.upm.dit.isst.webLab.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;

@Entity
@Table(name = "INTERESES", uniqueConstraints = {
		@UniqueConstraint(columnNames = "idintID")})
		//@UniqueConstraint(columnNames = "EMAIL")})
public class Intereses implements Serializable {

	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "idintID", unique = true, nullable = true)
	private Integer idintID; //FOREING KEY = PRIMARY KEY
	
	@ManyToOne
	private User userForm; 
	private String email; 
	
	private	String tiposecci�n;
	@Column(name = "DESCRIPCI�N", unique = false, nullable = true, length = 535)
	private String descripci�n;
	
	
	public Intereses() {}
	
	public Intereses( String email,String tipoSecci�n, String descripci�n) {
		this.email=email;
		this.tiposecci�n = tipoSecci�n;
		this.descripci�n = descripci�n;
	}
	
	
	
	
	public String getTipoSecci�n() {
		return tiposecci�n;
	}

	public void setTipoSecci�n(String tiposecci�n) {
		this.tiposecci�n = tiposecci�n;
	}
	
	
	
	public String getDescripci�n() {
		return descripci�n;
	}

	public void setDescripci�n(String descripci�n) {
		this.descripci�n = descripci�n;
	}

	public void setEmail(String email) {
		this.email=email;		
	}

	public void setUserForm(User user) {
		this.userForm=user;
		
	}
	public User getUserForm() {
		return userForm;
	}
	public String getEmail() {
		return email;
	}
	public int getidintID() {
		return idintID;
	}
	
}
