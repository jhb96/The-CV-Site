package es.upm.dit.isst.webLab.dao;

import java.util.ArrayList;
import java.util.Collection;

import javax.persistence.Query;

import org.hibernate.Session;
import es.upm.dit.isst.webLab.model.Intereses;

public class InteresesDAOImplementation implements InteresesDAO {

	private static InteresesDAOImplementation instancia = null;

	private InteresesDAOImplementation() {
	}

	public static InteresesDAOImplementation getInstance() {
		if (null == instancia)
			instancia = new InteresesDAOImplementation();
		return instancia;
	}

	@Override
	public void create(Intereses interes) {
		Session session = SessionFactoryService.get().openSession();
		try {
			session.beginTransaction();
			session.save(interes);
			session.getTransaction().commit();
		} catch (Exception e) {

		} finally {
			session.close();
		}				
	}

	@Override
	public Collection<Intereses>read(String email) {
		Session session = SessionFactoryService.get().openSession();
		Collection<Intereses> form = new ArrayList<Intereses>();
		try {
			session.beginTransaction();
			String query = "from Intereses WHERE EMAIL = '" + email + "'";
			form = session.createQuery(query).list();
			session.getTransaction().commit();
		} catch (Exception e) {

		} finally {
			session.close();
		}		
		return form;
	}

	@Override
	public void update(Intereses interes) {
		Session session = SessionFactoryService.get().openSession();
		try {
			session.beginTransaction();
			session.saveOrUpdate(interes);
			session.getTransaction().commit();
		} catch (Exception e) {

		} finally {
			session.close();
		}
	}

	@Override
	public void delete(Intereses interes) {
		Session session = SessionFactoryService.get().openSession();
		try {
			session.beginTransaction();
			session.delete(interes);
			session.getTransaction().commit();
		} catch (Exception e) {

		} finally {
			session.close();
		}
	}

	@SuppressWarnings("finally")
	@Override
	public Collection<Intereses> readAll() {
		Session session = SessionFactoryService.get().openSession();
		Collection<Intereses> inte = new ArrayList<Intereses>();
		try {
			session.beginTransaction();
			inte = session.createQuery("from Intereses").list();
			session.getTransaction().commit();
		} catch (Exception e) {

		} finally {
			session.close();
			return inte;
		}
	}
	public void delete(Integer id) {
		Session session = SessionFactoryService.get().openSession();
		try {
			session.beginTransaction();
			String query = "delete Intereses WHERE idintid = '" + id+"'";
			Query q = session.createQuery(query);
			q.executeUpdate();
			session.getTransaction().commit();
		} catch (Exception e) {

		} finally {
			session.close();
		}		
		return ;
	}

}
