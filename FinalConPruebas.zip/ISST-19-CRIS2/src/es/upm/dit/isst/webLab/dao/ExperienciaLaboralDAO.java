package es.upm.dit.isst.webLab.dao;

import java.util.Collection;

import es.upm.dit.isst.webLab.model.ExperienciaLaboral;

public interface ExperienciaLaboralDAO {
	
	public void create(ExperienciaLaboral exp); 
	
	public Collection<ExperienciaLaboral> read(String email);
	
	public void update(ExperienciaLaboral exp); 
	
	public void delete(ExperienciaLaboral exp); 
	
	public void delete(Integer id); 
	
	public Collection<ExperienciaLaboral> readAll();
	
	
}
